# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   J Nordbye  11/17/18, Added code to complete assignment 5
#   J Nordbye  11/18/18, Added code to enable changing priority
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#


# Display all todo items to user
def showItems(lstTable):
    print(" Task               Priority")
    for row in lstTable:
        spaces = ' ' * (20 - len(row['item']))  # number of spaces to pad between columns
        print(row['item'], spaces, row['pri'])


# end of showItems

# Add a new item to the list/Table
def addItem(lstTable):
    key = input(" Enter new item: ")
    value = input(" Enter priority: ")
    lstTable.append({"item": key, "pri": value})
    lstChanged[key] = "Added"



# end of addItem


# Remove an item from list/Table
def removeItem(lstTable):
    showItems(lstTable)
    index = -1

    strTask = input("Enter task you would like to remove: ")
    for row in lstTable:
        index += 1
        if row['item'] == strTask:
            break  # item found no need to go any further

    if index == -1:
        print(f" The item \"{strTask}\" was not found")
        return True  # not found nothing changed
    else:
        lstTable.pop(index)  # remove task
        lstChanged[strTask] = "Removed"
        return False  # changes have been made


# end of removeItem

# Save tasks to the ToDo.txt file
def saveData(lstTable):
    try:
        with open(objFileName, 'w') as fileOut:
            for row in lstTable:
                strOut = f"{row['item']},{row['pri']}\n"
                fileOut.write(strOut)
    except:
        msg = f" There was an error opening the file \"{objFileName}\" "
        print(msg)
        quit()

    print("The following changes were made")
    for key,value in lstChanged.items():
        print(f" The task \"{key}\" was changed to: {value}")
    lstChanged.clear()  #zero out dictionary to start new



# end of saveData

# Update priority
def updatePriority(lstTable):
    bolChangeMade = False
    index = -1
    print(" Which task would you like to update ? ")
    showItems(lstTable)
    
    strTask = input("Enter the task you would like to change the priority for: ")
    
    for list in lstTable:
        for item in list.items():
            (k,v) = item
            if  v == strTask:
                strPri=input(" Enter the new priority: ")
                list["pri"] = strPri
                lstChanged[strTask] = f"Priority {strPri}"
                bolChangeMade = True

    return bolChangeMade

        
    
            
        
    

# start of main script
# -------------------------------

objFileName = "Todo.txt"
dicRow = {}
lstTable = [] # list of tasks to do
lstChanged = {}  # list of tasks changed
dataSaved = True  # flag if data has changed since last save

# Step 1 - Load data from a file
try:
    with open(objFileName, 'r') as fileIn:
        for line in fileIn:
            dicAddRow = {}
            (key, value) = line.split(',')
            #used the string stip function to remove the new line character \n in value
            dicAddRow = {"item": key, "pri": value.strip()}
            lstTable.append(dicAddRow)

except:
    msg = f" There was an error opening the file \"{objFileName}\" "
    print(msg)
    quit()

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Change priority
    6) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 6] - "))
    print()  # adding a new line

    #Show the current items in the table
    if (strChoice.strip() == '1'):
        showItems(lstTable)
        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        addItem(lstTable)
        dataSaved = False  # set to false as we have added data to the list
        continue

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        dataSaved = removeItem(lstTable)  # will return false if changes made
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        if dataSaved:  # if true data has already been saved
            print(" No items have been added or removed")
        else:
            saveData(lstTable)
            dataSaved = True
        continue

    # Step 6 - Update Priority
    elif (strChoice == '5'):
        if updatePriority(lstTable):
            dataSaved = False  # set to false as we have changed data to the list
        continue
    
    elif (strChoice == '6'):
        if dataSaved == False:
            answer = input(" You have unsaved changes to you list, would you like to save before exiting (Y/N)")
            if answer.upper().startswith('Y'):
                saveData(lstTable)
                print(" Changes saved")
            else:
                print(" Script will exit without saving any changes")
        break  # and Exit the program

