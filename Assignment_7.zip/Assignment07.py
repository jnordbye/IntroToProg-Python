# -------------------------------------------------#
# Title: Exceptions and pickling module
# Dev:   JNordbye
# Date:  December/3/2018
# ChangeLog: (Who, When, What)
#   J Nordbye  12/3/18, Added code to complete assignment 5
#
# -------------------------------------------------#
import pickle #import the pickle Module

#=-------------------   Data -----------------------#
objFileName = "Inventory.dat"
objFileName2 = "Inventory2.dat"
lstInventoryDishes = [("Mug", 24.99, 5), ("Cup", 14.99, 10), ("Saucer", 9.99, 10)]    # list of items in inventory
lstInventoryUtensils =[("Knife", 9.99, 25), ("Fork", 4.99, 20), ("Spoon", 4.99, 10)]  # list of items in inventory


#------------------- Input/Output -------------------#
def listInventory( inInventory): # print out whats in the specifiedInventory
    for item in inInventory:
        print(f" {item[2]:2} {item[0]}(s) valued a {item[2]} each")
    print()  # add a line break in

def saveInventoryWhole(): # save the Dishes inventory as one object
    try:
        with open(objFileName, "wb") as fileOut:
           pickle.dump(lstInventoryDishes, fileOut)
    except Exception as e:
        print("Error with file")
        print(e)

def loadInventoryWhole(): # read the Dishes inventory in as one object
    global lstInventoryDishes
    try:
        with open(objFileName, "rb") as fileIn:
            lstInventoryDishes = pickle.load(fileIn)
    except Exception as e:
        print("Error with file")
        print(e)

def saveInventoryIndivd():  # save each part of the Utensil inventory individually
    try:
        objFile = open(objFileName2, "wb")
        for item in lstInventoryUtensils:
            pickle.dump(item, objFile)
        objFile.close()
    except Exception as e:
        print("Error with File")
        print(e)


def loadInventoryIndivd(): # load each item from disk and add to the Utensil Inventory
    try:
        with open(objFileName2, "rb") as inFile:
            while True:
                try:
                    item = pickle.load(inFile)
                    lstInventoryUtensils.append(item)
                except EOFError: # error check for reaching end of file.
                    break
                except Exception as e:
                    print("Error with file")
                    print(e)
                    break
    except Exception as e:
        print("Error with file")
        print(e)

#------------------- Processing ---------------------#
saveInventoryWhole()  # save the Dishes inventory
lstInventoryDishes.clear()  # clear out the list
loadInventoryWhole() # load the dishes inventory in from file
print("Dishes Inventory")
listInventory(lstInventoryDishes) # print out the Dishes list

saveInventoryIndivd() # save utensiles inventory to file
lstInventoryUtensils.clear() # clear the list
loadInventoryIndivd() # load the utensiles inventory in
print("Utensil Inventory")
listInventory(lstInventoryUtensils)
