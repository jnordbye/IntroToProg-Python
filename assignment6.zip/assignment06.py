# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   J Nordbye  11/25/18, Added code to complete assignment 5
#
# -------------------------------------------------#

#=-------------------   Data -----------------------#

objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []
lstReload = [{"item":"Clean House","pri":"Low"},{"item":"Pay Bills","pri":"High"}]
lstReloadBad = [{"item":"Clean House","pri":"Low"},{"item":"Pay Bills","pri":"High"}, 2]
dataSaved = True  # flag if data has changed since last save

#------------------- Input/Output -------------------#

class ToDoList(object):

    def __init__(self, ListIn=None):
        self.lstTable = []

        if ListIn is not None: # Check to see if we have passed a list in
            if isinstance(ListIn, list): # is it really a list
                for inline in ListIn: # guess so but does it contain only dictionarys
                    if not isinstance(inline, dict): # is this entry a dictionary
                        print("Not a list of Dictionary's") # nope
                        quit()
                self.lstTable = ListIn.copy() # input list is good copy to working list
            else:
                print("Input is not a list") # input was not a list
                # quit()
        else:
            self.loadData() # nothing passed in load from file

    def loadData(self):

        try:
            with open(objFileName, 'r') as fileIn:
                for line in fileIn:
                    dicAddRow = {}
                    (key, value) = line.split(',')
                    # dicAddRow[key] = value.strip()  #added strip to remove new line character \n
                    dicAddRow = {"item": key, "pri": value.strip()}
                    self.lstTable.append(dicAddRow)

        except:
            msg = f" There was an error opening the file \"{objFileName}\" "
            print(msg)
            quit()

    def showItems(self):
        print(" Task               Priority")
        for row in self.lstTable:
            print(f" {row['item']:20} {row['pri']}")

    def addItem(self):
        key = input(" Enter new item: ")
        value = input(" Enter priority: ")
        self.lstTable.append({"item": key, "pri": value})
        return False

    def removeItem(self):
        self.showItems()
        index = -1

        strTask = input("Enter task you would like to remove: ")
        for row in self.lstTable:
            index += 1
            if row['item'] == strTask:
                break  # item found no need to go any further

        if index == -1:
            print(f" The item \"{strTask}\" was not found")
        else:
            self.lstTable.pop(index)  # remove task
            return False # changes have been made

    def saveData(self):
        try:
            with open(objFileName, 'w') as fileOut:
                for row in self.lstTable:
                    strOut = f"{row['item']},{row['pri']}\n"
                    fileOut.write(strOut)
        except:
            msg = f" There was an error opening the file \"{objFileName}\" "
            print(msg)
            quit()

#------------------- Processing ---------------------#

#MyToDoList = ToDoList(lstReload) #use to load from list of dictionary
#MyToDoList = ToDoList(lstReloadBad) #use to test if everything in the list is a dictionary
MyToDoList=ToDoList()  #use to load from file at start


while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
     """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line

    # Show the current items in the table
    if (strChoice.strip() == '1'):
        MyToDoList.showItems()
        continue

    # Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        dataSaved=MyToDoList.addItem()
        continue

    # Remove a new item to the list/Table
    elif (strChoice == '3'):
        MyToDoList.removeItem()
        continue

    # Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        dataSaved=MyToDoList.saveData()
        continue

    elif (strChoice == '5'):
        if dataSaved == False:
            answer = input(" You have unsaved changes to you list, would you like to save before exiting (Y/N)")
            if answer.upper() == 'Y':
                MyToDoList.saveData()
                print(" Changes saved")
            else:
                print(" Script will exit without saving any changes")
        break  # and Exit the program

